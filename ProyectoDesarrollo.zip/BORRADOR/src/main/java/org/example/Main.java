package org.example;

import Interfaz.Login;



public class Main extends Login {

    public static void main(String[] args){

        Login login = new Login();
        login.frame();

    }

}