package org.example;


public class Usuario {

}